# Get the Full Pack

This free sample is one complete workflow — `website-monitor.json` — from the **n8n Business Automation Starter Pack** ($39). It's fully functional standalone: import it, connect your Telegram bot, and it works exactly as it does in the full pack.

## What's in the full pack (7 more workflows)

- `lead-capture.json` — Webhook form → validate → Google Sheets append → Telegram notify
- `invoice-reminder.json` — Daily overdue-invoice detection → Gmail reminder → Sheets update
- `daily-briefing.json` — Morning RSS + Sheets digest → Telegram message
- `client-onboarding.json` — Webhook → Sheets row → welcome email → 3-day automated follow-up
- `content-backup.json` — Weekly URL snapshot → change detection → Telegram alert
- `expense-logger.json` — Telegram message → parsed expense → Sheets row → confirmation
- `review-request.json` — Scheduled post-job review request emails, duplicate-send protected

Same standards as this sample: standard built-in n8n nodes only, no embedded credentials, a setup guide per workflow with the exact Google Sheet columns it expects, plus a SECURITY.md covering webhook token auth and least-privilege Google API scopes.

## Honest note

This sample and the full pack were validated as structurally correct, parseable JSON, but have not yet had a live end-to-end import pass in this release cycle — test each workflow against your own n8n instance using the included test procedures before relying on it for business-critical processes. Full details are on the product page.

See `products/n8n-starter-pack/commercial/listing.md` for the full product listing, or the product page at point of purchase.
