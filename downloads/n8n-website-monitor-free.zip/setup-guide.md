# Setup Guide (Free Sample): website-monitor.json

This is the complete, unmodified `website-monitor.json` workflow from the n8n Business Automation Starter Pack — free to use standalone. It checks a URL every 5 minutes and sends a Telegram alert when it goes down, with a cooldown so a flapping site doesn't spam you, plus a recovery message once it comes back.

## What it does

Schedule (every 5 min) → HTTP check the site → evaluate status + cooldown (Code node) → route to a down alert, a recovered alert, or no action, via Telegram.

## Requirements

- A working n8n instance (self-hosted or n8n Cloud), version 1.60 or later
- A Telegram bot token (create one by messaging @BotFather on Telegram, then `/newbot`)
- No Google Sheets or Gmail account needed — this workflow only uses Telegram

## Import steps

1. Open your n8n instance → **Workflows → Add workflow → Import from File**.
2. Select `website-monitor.json`.
3. Open the **"Check Site"** node and replace `https://example.com` with the URL you want monitored.
4. Open **"Alert - Site Down"** and **"Alert - Site Recovered"**:
   - Set the Telegram credential (create one under Credentials if you haven't already, using your bot token from @BotFather).
   - Replace `REPLACE_WITH_OWNER_CHAT_ID` in both nodes with your own Telegram chat ID.
   - To find your chat ID: message your bot once, then visit `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates` in a browser and read the `chat.id` field from the response.
5. Optional: open **"Evaluate + Cooldown"** (Code node) and adjust `COOLDOWN_MS` (default 30 minutes) if you want alerts to repeat more or less often while the site stays down.

## Test procedure

1. Click **Execute Workflow** once with the real, working URL — confirm the Evaluate node reports `isDown: false, action: "none"` and no Telegram message is sent.
2. Temporarily point "Check Site" at a URL you control that returns an error (a path you know 404s, or a host you can briefly take offline) and re-run — confirm you get the "Site is DOWN" Telegram message.
3. Re-run again immediately — confirm no second alert fires (cooldown active).
4. Point "Check Site" back at the healthy URL and re-run — confirm you get the "Site has RECOVERED" message.
5. Once confirmed, point "Check Site" at your real production URL and activate the workflow.

## A note on how state is kept

This workflow uses n8n's workflow static data (not Google Sheets or a database) to remember whether the site was previously down and when the last alert fired. This persists as long as the workflow stays saved/active on the same n8n instance — it is not shared across duplicate copies of the workflow, and depends on your instance not running in a purely in-memory/ephemeral mode.

## This is one of 8 workflows

See `get-the-full-pack.md` in this folder for what else is in the full n8n Business Automation Starter Pack.
